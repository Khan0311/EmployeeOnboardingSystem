package EOS_Service;

import java.util.ArrayList;

import EOS_Dao.EmployeeDAO;
import EOS_Entity.Employee;

public class EmployeeService {
	private EmployeeDAO employeeDAO;

	public EmployeeService() {
		this.employeeDAO = employeeDAO;
	}

	public void addEmployee(Employee employee) {
		employeeDAO.addEmployee(employee);
	}

	public Employee getEmployeeById(String id) {
		return employeeDAO.getEmployeeById(id);
	}

	public void updateEmployee(Employee updatedEmployee) {
		employeeDAO.updateEmployee(updatedEmployee);
	}

	public void removeEmployee(String id) {
		employeeDAO.removeEmployee(id);
	}

	public ArrayList<Employee> getAllEmployees() {
		return employeeDAO.getAllEmployees();
	}
}
