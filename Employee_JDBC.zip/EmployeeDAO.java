package EOS_Dao;

import java.util.ArrayList;

import EOS_Entity.Employee;

public class EmployeeDAO {
	private ArrayList<Employee> employees;

	public EmployeeDAO() {
		this.employees = new ArrayList<>();
	}

	public void addEmployee(Employee employee) {
		employees.add(employee);
	}

	public Employee getEmployeeById(String id) {
		for (Employee employee : employees) {
			if (employee.getId().equals(id)) {
				return employee;
			}
		}
		return null;
	}

	public void updateEmployee(Employee updatedEmployee) {
		for (Employee employee : employees) {
			if (employee.getId().equals(updatedEmployee.getId())) {
				employee.setName(updatedEmployee.getName());
				employee.setPosition(updatedEmployee.getPosition());
				return;
			}
		}
	}

	public void removeEmployee(String id) {
		employees.removeIf(employee -> employee.getId().equals(id));
	}

	public ArrayList<Employee> getAllEmployees() {
		return new ArrayList<>(employees);
	}
}
//package com.dao;
//
//import java.sql.Connection;
//import java.sql.SQLException;
//import java.sql.Statement;
//import com.jdbc.JDBC_Conn;
//
//public class EmpDao {
//    public String createTable(String tableName) throws SQLException {
//        String query = "CREATE TABLE " + tableName + " (eID INT PRIMARY KEY, "
//                + "eName VARCHAR(55), eAddress VARCHAR(100), eSalary DOUBLE)";
//
//        Connection con = JDBC_Conn.getConnectionOBJ();
//        Statement stm = con.createStatement();
//        stm.execute(query);
//        return "Table created successfully!";
//    }
//
//    public String insertEmp(int eId, String eName, String eAddress, double eSalary) throws SQLException {
//        String query = "INSERT INTO employee VALUES(" + eId + ", '" + eName + "', '" + eAddress + "', " + eSalary + ")";
//
//        Connection con = JDBC_Conn.getConnectionOBJ();
//        Statement stm = con.createStatement();
//        stm.execute(query);
//
//        return "Data inserted successfully!";
//    }
//
//    // Add more methods for updating and other operations as needed
//}
