package EOS_Controller;

import EOS_Service.EmployeeService;
import EOS_Entity.Employee;

import java.util.InputMismatchException;
import java.util.Scanner;

public class EmployeeController {
    private EmployeeService employeeService;
    private Scanner scanner;

    public EmployeeController(EmployeeService employeeService, Scanner scanner) {
        this.employeeService = employeeService;
        this.scanner = scanner;
    }

    public void start() {
        int choice;

        do {
            try {
                displayMenu();
                System.out.print("Enter your choice: ");
                choice = scanner.nextInt();
                scanner.nextLine(); // Consume the newline character

                switch (choice) {
                    case 1:
                        addEmployee();
                        break;
                    case 2:
                        updateEmployee();
                        break;
                    case 3:
                        removeEmployee();
                        break;
                    case 4:
                        displayAllEmployees();
                        break;
                    case 5:
                        searchEmployee();
                        break;
                    case 0:
                        System.out.println("Exiting the Employee Onboarding System. Goodbye!");
                        break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a valid number.");
                scanner.nextLine(); // Consume the invalid input
                choice = -1; // Set choice to an invalid value to continue the loop
            } catch (Exception e) {
                System.out.println("An error occurred: " + e.getMessage());
                choice = -1; // Set choice to an invalid value to continue the loop
            }
        } while (choice != 0);

        // Close the scanner to avoid resource leaks
        scanner.close();
    }

    private void displayMenu() {
        System.out.println("--------------------------");
        System.out.println("Employee Onboarding System");
        System.out.println("--------------------------");
        System.out.println("1. Add Employee Registration");
        System.out.println("2. Update Employee Details");
        System.out.println("3. Remove Employee");
        System.out.println("4. Display All Employees");
        System.out.println("5. Search Employee");
        System.out.println("0. Exit");
    }

    private void addEmployee() {
        System.out.println("Add Employee Registration");

        System.out.print("Enter Employee ID: ");
        String id = scanner.nextLine();

        System.out.print("Enter Employee Name: ");
        String name = scanner.nextLine();

        System.out.print("Enter Employee Position: ");
        String position = scanner.nextLine();

        Employee employee = new Employee(id, name, position);
        employeeService.addEmployee(employee);

        System.out.println("Employee added successfully!");
    }

    private void updateEmployee() {
        System.out.println("Update Employee Details");

        System.out.print("Enter Employee ID to update: ");
        String id = scanner.nextLine();

        Employee existingEmployee = employeeService.getEmployeeById(id);

        if (existingEmployee != null) {
            System.out.print("Enter new Employee Name: ");
            String name = scanner.nextLine();

            System.out.print("Enter new Employee Position: ");
            String position = scanner.nextLine();

            Employee updatedEmployee = new Employee(id, name, position);
            employeeService.updateEmployee(updatedEmployee);

            System.out.println("Employee details updated successfully!");
        } else {
            System.out.println("Employee with ID " + id + " not found.");
        }
    }

    private void removeEmployee() {
        System.out.println("Remove Employee");

        System.out.print("Enter Employee ID to remove: ");
        String id = scanner.nextLine();

        Employee existingEmployee = employeeService.getEmployeeById(id);

        if (existingEmployee != null) {
            employeeService.removeEmployee(id);
            System.out.println("Employee removed successfully!");
        } else {
            System.out.println("Employee with ID " + id + " not found.");
        }
    }

    private void displayAllEmployees() {
        System.out.println("Displaying All Employees");

        if (employeeService.getAllEmployees().isEmpty()) {
            System.out.println("No employees found.");
        } else {
            for (Employee employee : employeeService.getAllEmployees()) {
                System.out.println(employee);
            }
        }
    }

    private void searchEmployee() {
        System.out.println("Search Employee");

        System.out.print("Enter Employee ID to search: ");
        String id = scanner.nextLine();

        Employee foundEmployee = employeeService.getEmployeeById(id);

        if (foundEmployee != null) {
            System.out.println("Employee found:");
            System.out.println(foundEmployee);
        } else {
            System.out.println("Employee with ID " + id + " not found.");
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        EmployeeService employeeService = new EmployeeService(); // Assuming you have an EmployeeService class

        EmployeeController employeeController = new EmployeeController(employeeService, scanner);
        employeeController.start();
    }
}

