package EOS_jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Employee_JDBC {
	public static Connection getConnectionOBJ() {
		String userName = "root";
		String password = "Sana@9022";
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("Step 1");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

		Connection con = null;
		try {
			// Modify the URL to use your "db" database
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db", userName, password);
			System.out.println("Step 2");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return con;
	}
}
